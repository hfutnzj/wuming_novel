<?php
/**
 * �û�����
 * 
 * @version        $Id: feedback.php 1 8:38 2010��7��9��Z tianya $
 * @package        DedeCMS.Member
 * @copyright      Copyright (c) 2007 - 2010, DesDev, Inc.
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */
$cfg_formmember = true;
require_once(dirname(__FILE__).'/../plus/feedback.php');