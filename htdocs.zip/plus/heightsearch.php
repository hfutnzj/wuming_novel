<?php
/**
 *
 * �߼�����
 *
 * @version        $Id: heightsearch.php 1 15:38 2010��7��8��Z tianya $
 * @package        DedeCMS.Site
 * @copyright      Copyright (c) 2007 - 2010, DesDev, Inc.
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */
require_once(dirname(__FILE__).'/../include/common.inc.php');
require_once(DEDEINC.'/typelink.class.php');
require_once(DEDETEMPLATE.'/plus/heightsearch.htm');